<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td valign="top" class="lightbg"><table width="100%"  border="0" cellpadding="0" cellspacing="0">
        <tr>
          <td valign="top"><table width="100%"  border="0" cellspacing="0" cellpadding="0">
              <tr>
                <td height="25" class="heading2">&nbsp;Admin Site</td>
              </tr>
              <tr>
                <td height="22"><span onclick="location.replace('index.php');" onmouseover="this.className='mouseOve';this.className='mouseOve'; window.status='Click here to go to Main Page'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " class="mycustum" style="cursor: pointer;">&nbsp;&nbsp;&#8226; Home</span></td>
              </tr>
               <tr>
                <td class="linebg" height="1"></td>
              </tr>
              <tr>
                <td height="22"><span onclick="window.open('../','_blank');" onmouseover="this.className='mouseOve';this.className='mouseOve'; window.status='Click here to Visit Your Website'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " class="mycustum" style="cursor: pointer;">&nbsp;&nbsp;&#8226; Preview Website</span></td>
              </tr>
              <tr>
                <td class="linebg" height="1"></td>
              </tr>
              <tr>
                <td height="22"><span onclick="location.replace('changepswd.php');" onmouseover="this.className='mouseOve';this.className='mouseOve'; window.status='Click here to Change your Password'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " class="mycustum" style="cursor: pointer;">&nbsp;&nbsp;&#8226; Change Password</span></td>
              </tr>
              <tr>
                <td class="linebg" height="1"></td>
              </tr>
              <tr>
                <td height="22"><span onclick="location.replace('logout.php');" onmouseover="this.className='mouseOve';window.status='Click here to Termainate your Session'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Logout</span></td>
              </tr>
              <tr>
                <td class="linebg" height="1"></td>
              </tr>
              <tr>
                <td height="20">&nbsp;</td>
              </tr>
            </table></td>
        </tr>
        <tr>
          <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
							<tr>
                <td height="25" class="heading2">&nbsp;Manage Info</td>
              </tr>
              <tr>
                <td height="22"><span onclick="location.replace('cms.php');" onmouseover="this.className='mouseOve';window.status='Click here to Manage Contents'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Manage Contents</span></td>
              </tr>
							<tr>
                <td class="linebg" height="1"></td>
              </tr>
							<?php /*?><tr>
                <td height="22"><span onclick="location.replace('feedbacks.php');" onmouseover="this.className='mouseOve';window.status='Click here to Manage Feedback'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Manage Feedbacks</span></td>
              </tr><?php */?>
							<tr>
                <td class="linebg" height="1"></td>
              </tr>
							<tr>
                <td height="22"><span onclick="location.replace('testimonials.php');" onmouseover="this.className='mouseOve';window.status='Click here to Manage Testimonials'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Manage Testimonials</span></td>
<!--              </tr>
                <td class="linebg" height="1"></td>
              </tr>

              <tr>
                <td height="22"><span onclick="location.replace('adds.php');" onmouseover="this.className='mouseOve';window.status='Click here to Termainate your Session'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Advertisements</span></td>
              </tr> -->
							<tr>
                <td class="linebg" height="1"></td>
              </tr>
							<tr>
							  <td>&nbsp;</td>
						  </tr>
                          
                        <tr>
                <td class="linebg" height="1"></td>
              </tr>
              <tr>
                <td height="22"><span onclick="location.replace('metahome.php');" onmouseover="this.className='mouseOve';window.status='Click here to Termainate your Session'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Meta Home</span></td>
              </tr>
              
<tr>
             
              
            </table></td>
        </tr>
        <?php /*?><tr>
          <td><table width="100%"  border="0" cellspacing="0" cellpadding="0">
            <tr>
              <td height="25" class="heading2">&nbsp;Manage Hotels </td>
            </tr>
            <tr>
              <td height="22"><span onclick="location.replace('cities.php');" onmouseover="this.className='mouseOve';window.status='Click here to Manage Cities'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Manage Cities </span></td>
            </tr>
            <tr>
              <td class="linebg" height="1"></td>
            </tr>
            <tr>
              <td height="22"><span onclick="location.replace('hotels.php');" onmouseover="this.className='mouseOve';window.status='Click here to Manage Hotels'; return true " onmouseout="this.className='mouseOute'; window.status=''; return true " style="cursor: pointer;">&nbsp;&nbsp;&#8226; Manage Hotels </span></td>
            </tr>
            <tr>
              <td class="linebg" height="1"></td>
            </tr>

          </table></td>
        </tr><?php */?>
      </table></td>
  </tr>
</table>
